<?php
/**
 * F7 Medical Equipment functions and definitions
 */

if (!function_exists('f7_medical_theme_setup')) {
    function f7_medical_theme_setup() {
        add_theme_support('title-tag');
        add_theme_support('post-thumbnails');
    }
}
add_action('after_setup_theme', 'f7_medical_theme_setup');

if (!function_exists('f7_add_module_type')) {
    function f7_add_module_type($tag, $handle, $src) {
        if (strpos($src, 'index-') !== false && strpos($src, '.js') !== false) {
            return '<script type="module" src="' . esc_url($src) . '"></script>';
        }
        return $tag;
    }
}
add_filter('script_loader_tag', 'f7_add_module_type', 10, 3);
